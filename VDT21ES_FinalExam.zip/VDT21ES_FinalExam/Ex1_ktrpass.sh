#!/bin/bash

if [ -z "$1" ]; then
	echo "Nhap mot mat khau de kiem tra: "
	exit 1
fi

password="$1"

#ktr do dai
if [[ ${#password} -lt 8 ]]; then
	echo "Mat khau khong du do dai (>= 8 ky tu)."
	exit 1
fi

# check at least 1 char
if ! [[ "$password" =~ [0-9] ]]; then
	echo "Mat khau phai it nhat mot chu so."
	exit 1
fi

#Ktr chu HOA va 1 chu thuong
if ! [[ "$password" =~ [A-Z] ]]; then
	echo "Mat khau phai it nhat 1 chu cai viet HOA."
	exit 1
fi
if ! [[ "$password" =~ [a-z] ]]; then
	echo "Mat khau phai it nhat 1 chu cai viet thuong."
	exit 1
fi

# ktr 1 ky tu dac biet
if ! [[ "$password" =~ [\!\@\#\$\%\^\&\*] ]]; then
	echo "Mat khai phai it nhat 1 ky tu dac biet (!@#$%^&*)."
	exit 1
fi

#ktr ky tu space
if [[ "$password" =~ [[:space:]] ]]; then
	echo "Mat khau khong duoc chua khoang trang (space)."
	exit 1
fi

echo "Mat Khau Hop Le."
exit 0
